<?php
	// Set logged user to online
	$chat->set_user_sessionStatus($chat->clientID, 'ONLINE');
?>