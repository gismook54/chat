<?php
	
	// DB Connection Configuration
	define('DB_HOST', 'localhost'); 
	define('DB_USERNAME', 'fcom_covid'); 
	define('DB_PASSWORD', '#eYfs08IJ6cw*2020'); 
	define('DATABASE', 'admin_fordbc'); 
	define('TABLE', 'messages');
	define('USERS_TABLE', 'usersg11');
	
?>